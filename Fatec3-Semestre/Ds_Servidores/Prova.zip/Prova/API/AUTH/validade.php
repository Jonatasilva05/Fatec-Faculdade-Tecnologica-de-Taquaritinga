<?php
require_once '../config.php';

$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['email'], $input['senha'])) {
    $email = $input['email'];
    $senha = $input['senha'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND senha = ?");
    $stmt->execute([$email, $senha]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        echo json_encode(["message" => "Usuário autenticado", "user" => $user]);
    } else {
        echo json_encode(["error" => "Credenciais inválidas"]);
    }
} else {
    echo json_encode(["error" => "Dados incompletos"]);
}
?>
