<?php

require_once '../DATABASE/conexao.php';
header('Content-Type: application/json');

?>